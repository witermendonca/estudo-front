export const MAX_TYPED_KEYS = 30;
export const WORD_ANIMATION_INTERVAL = 200;
export const TIMER_DURATION = 10;
