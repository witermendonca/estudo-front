[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)

# Typing Game

[![!Typing Game](http://i3.ytimg.com/vi/cRFJZ80jxX4/maxresdefault.jpg)](https://www.youtube.com/watch?v=cRFJZ80jxX4).

Projeto da ***Maratona JS 3***.

O conteúdo desse repositório, faz parte do material didático do curso "Dev Sem Fronteiras", 
também conhecido como "Curso de React/NodeJS" do [Emerson Brôga Dev](https://emersonbroga.com/instagram).

<p align="left">
Feito com <img src="https://img.icons8.com/color/48/000000/like--v3.png" width="20" height="20" /> usando <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg" alt="React" width="20" height="20"/>. Esse repositório e o video têm fins educativos.
</p>

<img src="https://emersonbroga.com/e/assets/emersonbroga-logo-name-pink.png" alt="Emerson Broga Logo Pink"  height="80"/>

#### Se ainda não segue, veja minhas outras Redes Sociais

[![instagram.com/emersonbrogadev](https://github.com/emersonbroga/social-media-snippets/blob/master/static/instagram.png?raw=true)](https://emersonbroga.com/instagram) 
[![youtube.com/c/emersonbrogadev](https://github.com/emersonbroga/social-media-snippets/blob/master/static/youtube.png?raw=true)](https://emersonbroga.com/youtube)
[![facebook.com/emersonbrogadev](https://github.com/emersonbroga/social-media-snippets/blob/master/static/facebook.png?raw=true)](https://emersonbroga.com/facebook)
[![twitter.com/emersonbrogadev](https://github.com/emersonbroga/social-media-snippets/blob/master/static/twitter.png?raw=true)](https://emersonbroga.com/twitter)
[![github.com/emersonbroga](https://github.com/emersonbroga/social-media-snippets/blob/master/static/github.png?raw=true)](https://emersonbroga.com/github)


## Você fez também?

Se você fizer o projeto tambem, me manda o link que eu coloco aqui, ou então envia uma PR!

- [@emersonbroga](https://github.com/emersonbroga/super-shoes)

  



  
