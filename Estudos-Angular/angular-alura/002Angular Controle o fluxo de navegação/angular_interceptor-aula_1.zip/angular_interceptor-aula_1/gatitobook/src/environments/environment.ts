export const environment = {
  production: false,
  apiURL: 'http://localhost:3000',
};
