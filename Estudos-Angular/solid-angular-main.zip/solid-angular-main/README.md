# solid-angular

This content refer to pratice application to concept SOLID, from Uncle Bob, in Angular 12+.

<ul>
 <li><b>S</b>ingle Responsiblity Principle</li>
 <li><b>O</b>pen-Closed Principle</li>
 <li><b>L</b>iskov Substitution Principle</li>
 <li><b>I</b>nterface Segregation Principle</li>
 <li><b>D</b>ependency Inversion Principle</li>
</ul>

