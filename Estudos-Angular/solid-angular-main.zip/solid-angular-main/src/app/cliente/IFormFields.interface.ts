import { FormInputType } from "../form-input/input-type/form-input-type.class";

export interface IFormFields{
    getFormFields(): FormInputType[];
}