const cliente = {
  nome:"Andre",
  idade:36,
  cpf:"12543652266",
  email:"andre@email.com"
}

console.log(cliente);

cliente.fone ="9242525252"

console.log(cliente);

cliente.fone ="875254554"

console.log(cliente)