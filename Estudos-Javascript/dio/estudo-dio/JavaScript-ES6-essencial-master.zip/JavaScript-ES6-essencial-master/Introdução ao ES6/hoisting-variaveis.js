function fn() {
  console.log(text);

  var text = "Exemplo";

  console.log(text);
}

fn();

/**
 function fn() {
     var text;
     console.log(text);
     text = 'Exemplo';
     console.log(text);
 }
 */