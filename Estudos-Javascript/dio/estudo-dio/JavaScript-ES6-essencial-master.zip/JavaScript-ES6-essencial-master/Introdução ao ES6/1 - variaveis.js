var nameVar = "Bruna";
let nameLet = "Bruna";
const nameConst = "Bruna";

console.log(`nameVar: ${nameVar}`);
console.log(`nameLet: ${nameLet}`);
console.log(`nameConst: ${nameConst}`);