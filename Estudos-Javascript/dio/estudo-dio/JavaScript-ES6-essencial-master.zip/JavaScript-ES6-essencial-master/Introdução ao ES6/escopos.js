
// escopo global

{
  // escopo de bloco
}

function test() {
  // escopo de função
}