var meuNumero = 20;
var meuTexo = "Exemplo";

console.log(meuNumero + meuNumero);

