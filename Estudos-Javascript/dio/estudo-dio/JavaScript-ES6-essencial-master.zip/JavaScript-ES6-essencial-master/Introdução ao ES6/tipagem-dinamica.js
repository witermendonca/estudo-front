var minhaVariavel = 30; //number

 minhaVariavel = "Texto"; // string

 console.log(minhaVariavel);