/**
 for ([expressaoInicial]; [condicao]; [incremento])
 declaracao
 */

 const array = ['one', 'two', 'three'];

 for(let index = 0; index < array.length; index++) {
    const element = array[index];
    console.log(`Element #${item}: ${element}`);
 }
