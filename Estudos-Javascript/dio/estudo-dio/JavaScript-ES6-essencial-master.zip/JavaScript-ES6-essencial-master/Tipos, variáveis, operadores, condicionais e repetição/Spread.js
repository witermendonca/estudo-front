// Spread ...
var partes = ['ombro', 'joelho'];
var musica = ['cabeca',...partes, 'e', 'pés'];

var musica = ['cabeca','ombro', 'joelho', 'e', 'pés'];

function fn(x, y, z){}
var args = [0,1,2];
fn (...args);