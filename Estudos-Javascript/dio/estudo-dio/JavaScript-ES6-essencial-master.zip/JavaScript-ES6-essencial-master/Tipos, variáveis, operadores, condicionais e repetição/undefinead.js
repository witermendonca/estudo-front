let undefinedVariable;

console.log('Tipo da variavel', typeof undefinedVariable);

//Utilizada para verificar ser esta definida