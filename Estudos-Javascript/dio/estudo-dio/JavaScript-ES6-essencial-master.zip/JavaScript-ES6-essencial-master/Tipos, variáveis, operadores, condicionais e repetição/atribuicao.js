// Atribuição
x = y

// Atribuição de adição
x = x + y // ou
x += y

//Atribuição de substração
x = x - y // ou
x -= y

//Atribuição de multiplicação
x = x * y / y // ou
x /= y

//Atribuição de resto
x = x % y // ou
x %= y
