//Modulo(%)
//Operador binario. Retorna o inteiro restante dadivisão dos dois operados

12 % 5 //Retorna 2

// Incremento (++) e decremento (--)

++x
x++

const a = ++2; //3
const b = 2++; //2

++x
x++

//Negação (-) e Adição (+)
-3
+ "3"  //Retorna 3
+true //Retorna 1
+false //Retorna 0
- true //Retorna -1

//Operador de exponenciação (**)
2 ** 3 //Retorna 8
10 ** -1 //Retorna

//Operador de agrupamento ()
2 * (3 + 2)