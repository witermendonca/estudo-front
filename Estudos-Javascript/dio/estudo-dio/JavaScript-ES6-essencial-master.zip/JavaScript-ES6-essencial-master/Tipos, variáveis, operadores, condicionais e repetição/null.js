const nullVariable = null;

console.log(nullVariable);