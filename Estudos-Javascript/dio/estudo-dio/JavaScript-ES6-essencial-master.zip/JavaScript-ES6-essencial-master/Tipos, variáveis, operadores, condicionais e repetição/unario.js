//deletar algo

delete something;

//Determinar tipo
typeof something;