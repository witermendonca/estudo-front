const isActive = true;

const isAuthenticated = false;

console.log('tipo da variavel:', typeof isActive);