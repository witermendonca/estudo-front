/**
 do
 declaracao
 while(condicao);
 */

 let i = 0;
 do {
     i +=1;
     console.log(i);
} while(i < 5);