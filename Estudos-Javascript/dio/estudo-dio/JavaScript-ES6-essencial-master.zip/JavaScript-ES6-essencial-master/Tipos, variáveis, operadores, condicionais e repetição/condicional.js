//Ternario

condicao ? valor1 : valor2

true ? 'foo' :  'bar' //Retorna 'foo'
false ? 'foo': 'bar' //retorna bar