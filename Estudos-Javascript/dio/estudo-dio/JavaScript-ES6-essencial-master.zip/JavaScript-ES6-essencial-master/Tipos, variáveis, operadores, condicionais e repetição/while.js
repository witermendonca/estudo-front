/**
 while(Condicao)
 declaracao
 */

 var n = 0;
 var x = 0;

 while (n<3){
     n++;
    n += n; //1,3,6
 }

 console.log(x);